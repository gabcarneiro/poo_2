package com.company;

public class Paciente extends Pessoa {

    public Paciente(String nome) {
        super(nome);
    }

}
