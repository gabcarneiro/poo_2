package com.company;

public class ExameDiagnostico extends Exame{

    private double valorReferencial;
    private String diagnostico;

    public ExameDiagnostico(String descricao, String diagnostico) {
        super(descricao);
        this.diagnostico = diagnostico;
    }

    public double getValorReferencial() {
        return valorReferencial;
    }

    public void setValorReferencial(double valorReferencial) {
        this.valorReferencial = valorReferencial;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }
}
