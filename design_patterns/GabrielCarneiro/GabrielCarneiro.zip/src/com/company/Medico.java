package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Medico extends Pessoa {

    public Medico(String nome) {
        super(nome);
    }


    public SolicitacaoDeExame solicitarExames (Paciente p,
                                               String descricao, Exame... exames){

        SolicitacaoDeExame se = new SolicitacaoDeExame(p ,descricao, exames[0]);

        if (exames.length > 1){
            for (int i = 1; i < exames.length; i++) {
                se.addExame(exames[i]);
            }
        }

        se.setPaciente(p);
        se.setMedico(this);

        List<Exame> lista = se.getExames();
        Collections.sort(lista);
        se.setExames(lista);

        return se;
    }

}
