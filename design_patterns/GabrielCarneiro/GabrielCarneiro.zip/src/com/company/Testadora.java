package com.company;

public class Testadora {

    public static void main(String[] args) {

        //RESPOSTA DA QUESTAO DO ENADE = letra A

        Exame e1 = new ExameDiagnostico("Exame de Sangue", "Leucemia");
        Exame e2 = new ExameDiagnostico("Tomografia", "Cancer");

        Exame e3 = new ExameReferencial("Exame de gravidez", 100, 120);
        Exame e4 = new ExameReferencial("Exame de teste", 200, 250);

        Medico m1 = new Medico("Joelma");
        Paciente p1 = new Paciente("Ximbinha");

        Pessoa m12 = new Medico("Joelma");

        SolicitacaoDeExame se = m1.solicitarExames(p1,"Solicitacao de exanes", e1, e2, e3);

        for (Exame e :
                se.getExames()) {
            System.out.println(e.descricao);
        }



    }
}

