package com.company;

public class ExameReferencial extends Exame{

    private double valorReferencial;
    private double valorObtido;

    public ExameReferencial(String descricao, double valorReferencial, double valorObtido) {
        super(descricao);
        this.valorReferencial = valorReferencial;
        this.valorObtido = valorObtido;
    }

    public double getValorReferencial() {
        return valorReferencial;
    }

    public void setValorReferencial(double valorReferencial) {
        this.valorReferencial = valorReferencial;
    }

    public double getValorObtido() {
        return valorObtido;
    }

    public void setValorObtido(double valorObtido) {
        this.valorObtido = valorObtido;
    }
}
