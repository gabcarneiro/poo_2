package com.company;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class SolicitacaoDeExame {

    private List<Exame> exames = new ArrayList<>();
    private String descricaoConvenio;
    private Date dataEntrada;
    private Medico medico;
    private Paciente paciente;

    public void addExame(Exame exame){
        exames.add(exame);
    }

    public SolicitacaoDeExame(Paciente paciente, String descricao, Exame exame) {
        this.descricaoConvenio = descricao;
        this.paciente = paciente;
        this.exames.add(exame);
        Calendar c = Calendar.getInstance();
        dataEntrada = c.getTime();
    }

    public List<Exame> getExames() {
        return exames;
    }

    public void setExames(List<Exame> exames) {
        this.exames = exames;
    }

    public String getDescricaoConvenio() {
        return descricaoConvenio;
    }

    public void setDescricaoConvenio(String descricaoConvenio) {
        this.descricaoConvenio = descricaoConvenio;
    }

    public Date getDataEntrada() {
        return dataEntrada;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }
}
