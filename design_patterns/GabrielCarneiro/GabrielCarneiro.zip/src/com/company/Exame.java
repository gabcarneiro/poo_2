package com.company;

public abstract class Exame implements Comparable<Exame>{

    protected String descricao;

    public Exame(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Exame exame = (Exame) o;

        return descricao != null ? descricao.equals(exame.descricao) : exame.descricao == null;
    }

    @Override
    public int hashCode() {
        return descricao != null ? descricao.hashCode() : 0;
    }


    @Override
    public int compareTo(Exame e) {
        return this.getDescricao().compareTo(e.getDescricao());
    }
}
